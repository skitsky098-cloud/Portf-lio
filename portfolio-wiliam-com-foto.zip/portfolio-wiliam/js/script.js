// Uso de IA: ChatGPT, para criar um exemplo e ajudar a compreender HTML, CSS e JavaScript.
const botaoMenu = document.querySelector("#botaoMenu");
const listaMenu = document.querySelector("#listaMenu");
const botaoTema = document.querySelector("#botaoTema");
const formulario = document.querySelector("#formularioContato");

// Abre ou fecha o menu de navegação.
botaoMenu.addEventListener("click", function () {
    const menuAberto = listaMenu.classList.toggle("aberto");
    botaoMenu.setAttribute("aria-expanded", menuAberto);
    botaoMenu.setAttribute("aria-label", menuAberto ? "Fechar menu" : "Abrir menu");
});

// Retorna uma saudação conforme a hora recebida.
function obterSaudacao(hora) {
    if (hora < 12) return "Bom dia";
    else if (hora < 18) return "Boa tarde";
    else return "Boa noite";
}

// Atualiza a saudação com a hora atual.
function atualizarSaudacao() {
    const horaAtual = new Date().getHours();
    document.querySelector("#saudacao").textContent =
        obterSaudacao(horaAtual) + "! Seja bem-vindo ao meu portfólio.";
}
atualizarSaudacao();

// Alterna entre tema claro e escuro.
botaoTema.addEventListener("click", function () {
    const temaClaro = document.body.classList.toggle("tema-claro");
    botaoTema.textContent = temaClaro ? "🌙" : "☀️";
    botaoTema.setAttribute("aria-label", temaClaro ? "Ativar tema escuro" : "Ativar tema claro");
});

// Mostra um erro abaixo do campo indicado.
function mostrarErro(id, mensagem) {
    document.querySelector("#" + id).textContent = mensagem;
}

// Verifica se os campos do formulário são válidos.
function validarFormulario() {
    const nome = document.querySelector("#nome").value.trim();
    const email = document.querySelector("#email").value.trim();
    const mensagem = document.querySelector("#mensagem").value.trim();
    const consentimento = document.querySelector("#consentimento").checked;
    let valido = true;

    mostrarErro("erroNome", "");
    mostrarErro("erroEmail", "");
    mostrarErro("erroMensagem", "");
    mostrarErro("erroConsentimento", "");

    if (nome === "") {
        mostrarErro("erroNome", "Digite seu nome.");
        valido = false;
    }
    if (email === "") {
        mostrarErro("erroEmail", "Digite seu e-mail.");
        valido = false;
    } else if (!email.includes("@") || !email.includes(".")) {
        mostrarErro("erroEmail", "Digite um e-mail válido.");
        valido = false;
    }
    if (mensagem.length < 20) {
        mostrarErro("erroMensagem", "A mensagem deve ter pelo menos 20 caracteres.");
        valido = false;
    }
    if (!consentimento) {
        mostrarErro("erroConsentimento", "Marque a caixa de consentimento.");
        valido = false;
    }
    return valido;
}

// Valida o formulário sem enviar dados para um servidor.
formulario.addEventListener("submit", function (evento) {
    evento.preventDefault();
    const resultado = document.querySelector("#resultadoFormulario");
    if (validarFormulario()) {
        resultado.textContent = "Formulário validado com sucesso!";
        formulario.reset();
    } else {
        resultado.textContent = "Verifique os campos indicados antes de continuar.";
    }
});

// Insere o ano atual no rodapé.
function atualizarAno() {
    document.querySelector("#anoAtual").textContent = new Date().getFullYear();
}
atualizarAno();
